FILE STRUCTURE
    pa4
        4.1_rbtree
            include
                rbtree_impl.hpp
                rbtree.hpp
            src
                main.cpp

    - .tar files have been included to preserve original organization
            
COMPILATION INSTRUCTIONS
    
    - All 'main.cpp' source files assume include files will be found in the "../include" folder.
    
    - Compile 4.1_rbtree  ->  g++ -std=c++11 -o main main.cpp


EXECUTION INSTRUCTIONS

    - Execute   ->  ./main
    - Enter relative path and name of test dataset when prompted for file name.
